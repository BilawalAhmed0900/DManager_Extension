# DManager Extension

Extension for DManager

# Works with

Chrome and Firefox

# Adding to browser

## Chrome
    Load Unpacked in Chrome

## Firefox
    Add xpi from release in Firefox
